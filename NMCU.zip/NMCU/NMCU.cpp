/*
 * NMCU - Library for NMCU pins
 */